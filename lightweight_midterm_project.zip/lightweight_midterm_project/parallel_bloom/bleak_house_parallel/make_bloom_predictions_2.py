# -*- coding: utf-8 -*-
"""
Created on Fri Sep 27 22:21:48 2024

@author: Richard
"""
print('Importing libraries...')
import numpy as np
import transformers
from transformers import BloomForCausalLM
from transformers import BloomTokenizerFast
import torch
import os
print('Imports succesful')
print('Importing weights and biases...')
#model = BloomForCausalLM.from_pretrained("bigscience/bloom-1b3")
#tokenizer = BloomTokenizerFast.from_pretrained("bigscience/bloom-1b3")
model = BloomForCausalLM.from_pretrained("bigscience/bloom-1b1")
tokenizer = BloomTokenizerFast.from_pretrained("bigscience/bloom-1b1")
print('Imports succesful')

def make_bloom_prediction(prompt):
    prompt_word_length = prompt.count(' ')
    result_length= 30
    inputs = tokenizer(prompt, return_tensors="pt")
    
    # Greedy Search
    raw_result = tokenizer.decode(model.generate(inputs["input_ids"], 
                           max_length=result_length
                          )[0])
    result_output_only = raw_result[len(prompt):len(raw_result)]
    result_output_only = result_output_only.replace('?', '.') #replace all sentence ending punctuation with periods for easy splitting
    result_output_only = result_output_only.replace('!', '.')
    result_output_only = result_output_only.split('.')[0]
    output_string = prompt + '|' + result_output_only + '.'
    output_string = output_string.replace('\n', ' ') #replace output string newlines with spaces
    return output_string

curtailed_files_dir = 'curtailed_folder'
curtailed_filenames = os.listdir(curtailed_files_dir)
for curtailed_filename in curtailed_filenames:
    
    try:
        output_array = np.genfromtxt(curtailed_filename[0:-4] + '_bloom_prediction.txt', dtype='str', delimiter='\n')
        output_array = np.array(output_array)
        output_array = np.transpose(output_array)
        print('reading in existing output array file')
    except:
        print('writing new output array file')
        output_array = np.array(['This is the output document header'])
        np.savetxt(curtailed_filename[0:-4] + '_bloom_prediction.txt', output_array, delimiter = '\n', fmt="%s")
    #print(output_array)
    read_in_existing_filelength = output_array.size
    print('Existing filename length: ' + str(read_in_existing_filelength))
    text_string = np.genfromtxt(curtailed_files_dir + '\\' + curtailed_filename, dtype='str', delimiter='\n') #both the text string and the initial output array have a useless header
    for i in text_string[read_in_existing_filelength:len(text_string)]:
        #bloom_prediction = np.array([make_bloom_prediction(i)])
        bloom_prediction = make_bloom_prediction(i)
        #print(output_array)
        print(bloom_prediction)
        
        output_array = np.hstack((output_array, bloom_prediction))
        
        #if output_array.size%20 == 0:
        if output_array.size%20 == 0:
            np.savetxt(curtailed_filename[0:-4] + '_bloom_prediction.txt', output_array, delimiter = '\n', fmt="%s")