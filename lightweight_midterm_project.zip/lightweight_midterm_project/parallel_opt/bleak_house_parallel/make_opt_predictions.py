# -*- coding: utf-8 -*-
"""
Created on Fri Sep 27 22:21:48 2024

@author: Richard
"""
print('Importing libraries...')
import numpy as np
from transformers import AutoTokenizer, OPTForCausalLM
import torch
import os
import string
print('Imports succesful')
print('Importing weights and biases...')
model = OPTForCausalLM.from_pretrained("facebook/opt-350m")
tokenizer = AutoTokenizer.from_pretrained("facebook/opt-350m")
print('Imports succesful')

def strip_unprintable(data):
    return ''.join(c for c in data if c in string.printable)


def make_llm_prediction(prompt):
    prompt_word_length = prompt.count(' ')
    result_length = 35
    inputs = tokenizer(prompt, return_tensors="pt")
    generate_ids = model.generate(inputs.input_ids, max_length=result_length)
    raw_result = tokenizer.batch_decode(generate_ids, skip_special_tokens=True, clean_up_tokenization_spaces=False)[0]

    result_output_only = raw_result[len(prompt):len(raw_result)]
    result_output_only = result_output_only.replace('?', '.') #replace all sentence ending punctuation with periods for easy splitting
    result_output_only = result_output_only.replace('!', '.')
    result_output_only = result_output_only.split('.')[0]
    output_string = prompt + '|' + result_output_only + '.'
    output_string = output_string.replace('\n', ' ') #replace output string newlines with spaces
    output_string = strip_unprintable(output_string)
    return output_string

output_suffix = '_opt_prediction.txt'
curtailed_files_dir = 'curtailed_folder'
curtailed_filenames = os.listdir(curtailed_files_dir)
for curtailed_filename in curtailed_filenames:
    
    try:
        output_array = np.genfromtxt(curtailed_filename[0:-4] + output_suffix, dtype='str', delimiter='\n')
        output_array = np.array(output_array)
        output_array = np.transpose(output_array)
        print('reading in existing output array file')
    except:
        print('writing new output array file')
        output_array = np.array(['This is the output document header'])
        np.savetxt(curtailed_filename[0:-4] + output_suffix, output_array, delimiter = '\n', fmt="%s")

    read_in_existing_filelength = output_array.size
    print('Existing filename length: ' + str(read_in_existing_filelength))
    text_string = np.genfromtxt(curtailed_files_dir + '\\' + curtailed_filename, dtype='str', delimiter='\n') #both the text string and the initial output array have a useless header
    for i in text_string[read_in_existing_filelength:len(text_string)]:
        llm_prediction = make_llm_prediction(i)
        print(llm_prediction)
        
        output_array = np.hstack((output_array, llm_prediction))
        
        #if output_array.size%20 == 0:
        if output_array.size%20 == 0:
            np.savetxt(curtailed_filename[0:-4] + output_suffix, output_array, delimiter = '\n', fmt="%s")