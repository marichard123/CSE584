# -*- coding: utf-8 -*-
"""
Created on Sun Oct  6 19:43:05 2024

@author: Richard
"""
import os
import numpy as np



def load_dataset(data_dir_name, testing_prompts, validation_prompts, size_limit = 99999999999):
    """testing_files and validation_files determine the number of prompts taken from EACH text file, thus ensuring that
    the three datasets do not share prompts"""
    filenames = os.listdir(data_dir_name)
    testing_text = np.array([])
    testing_labels = np.array([])
    validation_text = np.array([])
    validation_labels = np.array([])
    validation_text = np.array([])
    validation_labels = np.array([])
    training_text = np.array([])
    training_labels = np.array([])
    
    for i in filenames:
        #print('bloom' in i)
        full_path_name = data_dir_name + '\\' + i
        text_strings = np.genfromtxt(full_path_name, dtype='str', delimiter='\n')
        text_strings = text_strings[1:len(text_strings)]
        labels = np.zeros(len(text_strings), dtype=int)
        if 'bloom' in i:
            labels+=0
        elif 'distilgpt2' in i:
            labels+=1
        elif 'opt' in i:
            labels+=2
        elif 'falcon' in i:
            labels+=3
            
        if len(text_strings) <= testing_prompts:
            testing_text = np.hstack((testing_text, text_strings))
            testing_labels = np.hstack((testing_labels, labels))
        else:
            testing_text = np.hstack((testing_text, text_strings[0:testing_prompts]))
            testing_labels = np.hstack((testing_labels, labels[0:testing_prompts]))
            
            if len(text_strings) <= testing_prompts + validation_prompts:
                validation_text = np.hstack((validation_text, text_strings[testing_prompts:len(text_strings)]))
                validation_labels = np.hstack((validation_labels, labels[testing_prompts:len(text_strings)]))
            else:
                validation_text = np.hstack((validation_text, text_strings[testing_prompts:testing_prompts+ validation_prompts]))
                validation_labels = np.hstack((validation_labels, labels[testing_prompts:testing_prompts+ validation_prompts]))  
                
                training_text = np.hstack((training_text, text_strings[testing_prompts+ validation_prompts:len(text_strings)]))
                training_labels = np.hstack((training_labels, labels[testing_prompts+ validation_prompts:len(text_strings)]))
    #print('here')         
    
    """Shuffle the order of training and validation data. Order doesn't matter for testing. The choice of testing data is deterministic
    for a given dataset"""
    testing_labels = testing_labels.astype(int)
    validation_labels = validation_labels.astype(int)
    training_labels = training_labels.astype(int)
    
    shuffled_indices = np.arange(len(validation_text))
    np.random.shuffle(shuffled_indices)
    validation_text = validation_text[shuffled_indices]
    validation_labels = validation_labels[shuffled_indices]
    shuffled_indices = np.arange(len(training_text))
    np.random.shuffle(shuffled_indices)
    training_text = training_text[shuffled_indices]
    training_labels = training_labels[shuffled_indices]
    
    return testing_text, testing_labels, validation_text, validation_labels, training_text, training_labels
        
testing_text, testing_labels, validation_text, validation_labels, training_text, training_labels = load_dataset('dataset', 1250, 1000, 9999999999)

print('Bloom in testing: ' + str(np.count_nonzero(testing_labels == 0)))
print('Distil GPT2 in testing: ' + str(np.count_nonzero(testing_labels == 1)))
print('OPT in testing: ' + str(np.count_nonzero(testing_labels == 2)))
print('Falcon in testing: ' + str(np.count_nonzero(testing_labels == 3)))
print('Total: ' + str(len(testing_labels)))
print(' ')
print(' ')
print('Bloom in validation: ' + str(np.count_nonzero(validation_labels == 0)))
print('Distil GPT2 in validation: ' + str(np.count_nonzero(validation_labels == 1)))
print('OPT in validation: ' + str(np.count_nonzero(validation_labels == 2)))
print('Falcon in validation: ' + str(np.count_nonzero(validation_labels == 3)))
print('Total: ' + str(len(validation_labels)))
print(' ')
print(' ')
print('Bloom in training: ' + str(np.count_nonzero(training_labels == 0)))
print('Distil GPT2 in training: ' + str(np.count_nonzero(training_labels == 1)))
print('OPT in training: ' + str(np.count_nonzero(training_labels == 2)))
print('Falcon in training: ' + str(np.count_nonzero(training_labels == 3)))
print('Total: ' + str(len(training_labels)))
print(' ')
print(' ')