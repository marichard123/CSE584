# -*- coding: utf-8 -*-
"""
Created on Sun Oct  6 21:25:10 2024

@author: Richard
"""
model_output_filename = 'saved_classification_nn_final.keras'
operation = 'train'


import os
os.environ["KERAS_BACKEND"] = "tensorflow"
import keras
import tensorflow as tf
import numpy as np
from keras import layers


current_files = os.listdir(os.getcwd())
if model_output_filename in current_files and operation =='train':
    raise ValueError('A saved file with the name' + model_output_filename + ' already exists. Pick a different name')
    
    
    
def load_dataset(data_dir_name, testing_prompts, validation_prompts, size_limit = 99999999999):
    """testing_files and validation_files determine the number of prompts taken from EACH text file, thus ensuring that
    the three datasets do not share prompts"""
    filenames = os.listdir(data_dir_name)
    testing_text = np.array([])
    testing_labels = np.array([])
    validation_text = np.array([])
    validation_labels = np.array([])
    validation_text = np.array([])
    validation_labels = np.array([])
    training_text = np.array([])
    training_labels = np.array([])
    
    for i in filenames:
        #print('bloom' in i)
        full_path_name = data_dir_name + '\\' + i
        text_strings = np.genfromtxt(full_path_name, dtype='str', delimiter='\n')
        text_strings = text_strings[1:len(text_strings)]
        labels = np.zeros(len(text_strings), dtype=int)
        if 'bloom' in i:
            labels+=0
        elif 'distilgpt2' in i:
            labels+=1
        elif 'opt' in i:
            labels+=2
        elif 'falcon' in i:
            labels+=3
            
        if len(text_strings) <= testing_prompts:
            testing_text = np.hstack((testing_text, text_strings))
            testing_labels = np.hstack((testing_labels, labels))
        else:
            testing_text = np.hstack((testing_text, text_strings[0:testing_prompts]))
            testing_labels = np.hstack((testing_labels, labels[0:testing_prompts]))
            
            if len(text_strings) <= testing_prompts + validation_prompts:
                validation_text = np.hstack((validation_text, text_strings[testing_prompts:len(text_strings)]))
                validation_labels = np.hstack((validation_labels, labels[testing_prompts:len(text_strings)]))
            else:
                validation_text = np.hstack((validation_text, text_strings[testing_prompts:testing_prompts+ validation_prompts]))
                validation_labels = np.hstack((validation_labels, labels[testing_prompts:testing_prompts+ validation_prompts]))  
                
                training_text = np.hstack((training_text, text_strings[testing_prompts+ validation_prompts:len(text_strings)]))
                training_labels = np.hstack((training_labels, labels[testing_prompts+ validation_prompts:len(text_strings)]))
    #print('here')         
    
    """Shuffle the order of training and validation data. Order doesn't matter for testing. The choice of testing data is deterministic
    for a given dataset"""
    testing_labels = testing_labels.astype(int)
    validation_labels = validation_labels.astype(int)
    training_labels = training_labels.astype(int)
    
    shuffled_indices = np.arange(len(validation_text))
    np.random.shuffle(shuffled_indices)
    validation_text = validation_text[shuffled_indices]
    validation_labels = validation_labels[shuffled_indices]
    shuffled_indices = np.arange(len(training_text))
    np.random.shuffle(shuffled_indices)
    training_text = training_text[shuffled_indices]
    training_labels = training_labels[shuffled_indices]
    
    return testing_text, testing_labels, validation_text, validation_labels, training_text, training_labels
        
testing_text, testing_labels, validation_text, validation_labels, training_text, training_labels = load_dataset('dataset', 1250, 1000, 9999999999)
#print(testing_labels)
#print(validation_labels)
#print(training_labels)
#print(len(testing_text))
#print(len(validation_text))
#print(len(training_text))

raw_test_ds = tf.data.Dataset.from_tensor_slices((testing_text, testing_labels))
batch_size = 128
raw_test_ds = raw_test_ds.batch(batch_size)

raw_val_ds = tf.data.Dataset.from_tensor_slices((validation_text, validation_labels))
batch_size = 128
raw_val_ds = raw_val_ds.batch(batch_size)


raw_train_ds = tf.data.Dataset.from_tensor_slices((training_text, training_labels))
batch_size = 128
raw_train_ds = raw_train_ds.batch(batch_size)

print(f"Number of batches in raw_train_ds: {raw_train_ds.cardinality()}")
print(f"Number of batches in raw_val_ds: {raw_val_ds.cardinality()}")
print(f"Number of batches in raw_test_ds: {raw_test_ds.cardinality()}")



import string
import re


def custom_standardization(input_data):
    lowercase = tf.strings.lower(input_data)
    stripped_html = tf.strings.regex_replace(lowercase, "<br />", " ")
    return tf.strings.regex_replace(
        stripped_html, f"[{re.escape(string.punctuation)}]", ""
    )


# Model constants.
max_features = 20000
embedding_dim = 128
sequence_length = 500


vectorize_layer = keras.layers.TextVectorization(
    standardize=custom_standardization,
    max_tokens=max_features,
    output_mode="int",
    output_sequence_length=sequence_length,
)


text_ds = raw_train_ds.map(lambda x, y: x)
vectorize_layer.adapt(text_ds)

def vectorize_text(text, label):
    text = tf.expand_dims(text, -1)
    return vectorize_layer(text), label



train_ds = raw_train_ds.map(vectorize_text)
val_ds = raw_val_ds.map(vectorize_text)
test_ds = raw_test_ds.map(vectorize_text)


train_ds = train_ds.cache().prefetch(buffer_size=10)
val_ds = val_ds.cache().prefetch(buffer_size=10)
test_ds = test_ds.cache().prefetch(buffer_size=10)






inputs = keras.Input(shape=(None,), dtype="int64")

# Next, we add a layer to map those vocab indices into a space of dimensionality 'embedding_dim'.
x = layers.Embedding(max_features, embedding_dim)(inputs)
x = layers.Dropout(0.5)(x)

# Conv1D + global max pooling
x = layers.Conv1D(128, 7, padding="valid", activation="relu", strides=3)(x)
x = layers.Conv1D(128, 7, padding="valid", activation="relu", strides=3)(x)
x = layers.Conv1D(128, 7, padding="valid", activation="relu", strides=3)(x)
x = layers.GlobalMaxPooling1D()(x)

# Vanilla hidden layer
x = layers.Dense(128, activation="relu")(x)
x = layers.Dropout(0.5)(x)

x = layers.Dense(128, activation="relu")(x)
x = layers.Dropout(0.5)(x)

# Project onto a 3-unit output layer, and use softmax for multi-class classification
predictions = layers.Dense(4, activation="softmax", name="predictions")(x)

# Create the model
model = keras.Model(inputs, predictions)

# Compile the model with categorical crossentropy loss and adam optimizer.
# Use sparse_categorical_crossentropy if your labels are integers.
model.compile(loss="sparse_categorical_crossentropy", optimizer="adam", metrics=["accuracy"])



epochs = 5


if operation == 'train':
    model.fit(train_ds, validation_data=val_ds, epochs=epochs)
    model.evaluate(test_ds)
    prediction = model.predict(test_ds)
    print(prediction)
    model.save(model_output_filename)
elif operation == 'predict':
    model = keras.models.load_model(model_output_filename)
    print('Using a saved model to make predictions on the training set: ')
    prediction = model.predict(test_ds)
    print(len(prediction))
    correct_predictions = 0
    incorrect_predictions = 0
    for index, i in enumerate(prediction):
        #if np.argmax(i) == testing_labels[index] and testing_labels[index] ==2: 
            print('Predicted: ' + str(np.argmax(i)) + '     True: ' +str(testing_labels[index]) + '     ' + testing_text[index] )
            
            if np.argmax(i) == testing_labels[index]:
                correct_predictions+=1
            else:
                incorrect_predictions+=1
    
    print('Prediction accuracy on testing set: ' + str(correct_predictions/(correct_predictions+incorrect_predictions)))
else:
    raise ValueError('You can set the operation to "train" or "predict". ' + operation + ' is not a valid operation')
