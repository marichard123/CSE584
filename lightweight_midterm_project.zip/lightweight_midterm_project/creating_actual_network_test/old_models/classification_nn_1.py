# -*- coding: utf-8 -*-
"""
Created on Fri Oct  4 21:24:30 2024

@author: Richard
"""
model_output_filename = 'saved_classification_nn_2.keras'
import os
os.environ["KERAS_BACKEND"] = "tensorflow"
import keras
import tensorflow as tf
import numpy as np
from keras import layers


current_files = os.listdir(os.getcwd())
if model_output_filename in current_files:
    raise ValueError('A file with the name' + model_output_filename + ' already exists. Pick a different name')


def load_dataset(data_dir_name, fraction_testing, subset_fraction_validation, size_limit = 99999999999):
    #If you're abble, modify it so that the training, validation, testing sets never share prompts. No time for that immediately thouhg.
    #data_dir_name = 'dataset'
    filenames = os.listdir(data_dir_name)
    all_text = np.array([])
    all_labels = np.array([])
    for i in filenames:
        #print('bloom' in i)
        full_path_name = data_dir_name + '\\' + i
        text_strings = np.genfromtxt(full_path_name, dtype='str', delimiter='\n')
        text_strings = text_strings[1:len(text_strings)]
        labels = np.zeros(len(text_strings), dtype=int)
        if 'bloom' in i:
            labels+=0
        elif 'distilgpt2' in i:
            labels+=1
        elif 'opt' in i:
            labels+=2
    
        all_text= np.hstack((all_text, text_strings))
        all_labels = np.hstack((all_labels, labels))
    

    
    
    all_labels = all_labels.astype(int)
    shuffled_indices = np.arange(len(all_text))
    np.random.shuffle(shuffled_indices)
    all_text = all_text[shuffled_indices]
    all_labels = all_labels[shuffled_indices]
    
    if len(all_text) > size_limit:
        all_text = all_text[0:size_limit]
        all_labels = all_labels[0:size_limit]
        
    #fraction_testing = 0.2
    #subset_fraction_validation = 0.2
    
    fraction_validation = (1-fraction_testing) * subset_fraction_validation
    testing_index = round(len(all_text) * fraction_testing)
    validation_index = testing_index + round(len(all_text) * fraction_validation)
    
    testing_text = all_text[0:testing_index]
    testing_labels = all_labels[0:testing_index]
    
    validation_text = all_text[testing_index:validation_index]
    validation_labels = all_labels[testing_index:validation_index]
    
    training_text =all_text[validation_index:len(all_text)]
    training_labels = all_labels[validation_index:len(all_text)]
    
    #print(len(testing_text))
    #print(' ')
    #print(len(validation_text))
    #print(' ')
    #print(len(training_text))
    
    #print(len(all_text))
    return testing_text, testing_labels, validation_text, validation_labels, training_text, training_labels




testing_text, testing_labels, validation_text, validation_labels, training_text, training_labels = load_dataset('dataset', 0.2, 0.2, 9999999999)


raw_test_ds = tf.data.Dataset.from_tensor_slices((testing_text, testing_labels))
# Batch the dataset (just like in the tutorial)
batch_size = 32
raw_test_ds = raw_test_ds.batch(batch_size)

raw_val_ds = tf.data.Dataset.from_tensor_slices((validation_text, validation_labels))
# Batch the dataset (just like in the tutorial)
batch_size = 32
raw_val_ds = raw_val_ds.batch(batch_size)


raw_train_ds = tf.data.Dataset.from_tensor_slices((training_text, training_labels))
# Batch the dataset (just like in the tutorial)
batch_size = 32
raw_train_ds = raw_train_ds.batch(batch_size)

print(f"Number of batches in raw_train_ds: {raw_train_ds.cardinality()}")
print(f"Number of batches in raw_val_ds: {raw_val_ds.cardinality()}")
print(f"Number of batches in raw_test_ds: {raw_test_ds.cardinality()}")



import string
import re


# Having looked at our data above, we see that the raw text contains HTML break
# tags of the form '<br />'. These tags will not be removed by the default
# standardizer (which doesn't strip HTML). Because of this, we will need to
# create a custom standardization function.
def custom_standardization(input_data):
    lowercase = tf.strings.lower(input_data)
    stripped_html = tf.strings.regex_replace(lowercase, "<br />", " ")
    return tf.strings.regex_replace(
        stripped_html, f"[{re.escape(string.punctuation)}]", ""
    )


# Model constants.
max_features = 20000
embedding_dim = 128
sequence_length = 500

# Now that we have our custom standardization, we can instantiate our text
# vectorization layer. We are using this layer to normalize, split, and map
# strings to integers, so we set our 'output_mode' to 'int'.
# Note that we're using the default split function,
# and the custom standardization defined above.
# We also set an explicit maximum sequence length, since the CNNs later in our
# model won't support ragged sequences.
vectorize_layer = keras.layers.TextVectorization(
    standardize=custom_standardization,
    max_tokens=max_features,
    output_mode="int",
    output_sequence_length=sequence_length,
)

# Now that the vectorize_layer has been created, call `adapt` on a text-only
# dataset to create the vocabulary. You don't have to batch, but for very large
# datasets this means you're not keeping spare copies of the dataset in memory.

# Let's make a text-only dataset (no labels):
text_ds = raw_train_ds.map(lambda x, y: x)
# Let's call `adapt`:
vectorize_layer.adapt(text_ds)

def vectorize_text(text, label):
    text = tf.expand_dims(text, -1)
    return vectorize_layer(text), label


# Vectorize the data.
train_ds = raw_train_ds.map(vectorize_text)
val_ds = raw_val_ds.map(vectorize_text)
test_ds = raw_test_ds.map(vectorize_text)

# Do async prefetching / buffering of the data for best performance on GPU.
train_ds = train_ds.cache().prefetch(buffer_size=10)
val_ds = val_ds.cache().prefetch(buffer_size=10)
test_ds = test_ds.cache().prefetch(buffer_size=10)





# A integer input for vocab indices.
inputs = keras.Input(shape=(None,), dtype="int64")

# Next, we add a layer to map those vocab indices into a space of dimensionality 'embedding_dim'.
x = layers.Embedding(max_features, embedding_dim)(inputs)
x = layers.Dropout(0.5)(x)

# Conv1D + global max pooling
x = layers.Conv1D(128, 7, padding="valid", activation="relu", strides=3)(x)
x = layers.Conv1D(128, 7, padding="valid", activation="relu", strides=3)(x)
x = layers.GlobalMaxPooling1D()(x)

# Vanilla hidden layer
x = layers.Dense(128, activation="relu")(x)
x = layers.Dropout(0.5)(x)

# Project onto a 3-unit output layer, and use softmax for multi-class classification
predictions = layers.Dense(3, activation="softmax", name="predictions")(x)

# Create the model
model = keras.Model(inputs, predictions)

# Compile the model with categorical crossentropy loss and adam optimizer.
# Use sparse_categorical_crossentropy if your labels are integers.
model.compile(loss="sparse_categorical_crossentropy", optimizer="adam", metrics=["accuracy"])



epochs = 3

# Fit the model using the train and test datasets.
model.fit(train_ds, validation_data=val_ds, epochs=epochs)
model.evaluate(test_ds)
prediction = model.predict(test_ds)
print(prediction)
model.save(model_output_filename)


"""
# A string input
inputs = keras.Input(shape=(1,), dtype="string")

# Turn strings into vocab indices
indices = vectorize_layer(inputs)

# Turn vocab indices into predictions
# Change the output layer to have 3 units and use softmax activation
outputs = layers.Dense(3, activation="softmax")(model(indices))

# Our end-to-end model
end_to_end_model = keras.Model(inputs, outputs)

# Compile the model with categorical crossentropy loss for multi-class classification
end_to_end_model.compile(
    loss="categorical_crossentropy",  # Use categorical crossentropy
    optimizer="adam",
    metrics=["accuracy"]
)

# Test it with `raw_test_ds`, which yields raw strings
end_to_end_model.evaluate(raw_test_ds)
"""

"""
print("stop here")
# A string input
inputs = keras.Input(shape=(1,), dtype="string")
#inputs = keras.Input(shape=(3,), dtype="string")
# Turn strings into vocab indices
indices = vectorize_layer(inputs)
# Turn vocab indices into predictions
outputs = model(indices)

# Our end to end model
end_to_end_model = keras.Model(inputs, outputs)
end_to_end_model.compile(
    loss="binary_crossentropy", optimizer="adam", metrics=["accuracy"]
)

# Test it with `raw_test_ds`, which yields raw strings
end_to_end_model.evaluate(raw_test_ds)
"""