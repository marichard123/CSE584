# -*- coding: utf-8 -*-
"""
Created on Sun Oct  6 19:53:36 2024

@author: Richard
"""
import numpy as np

def guess_on_distribution():
    event_1 = 7500
    event_2 = 10000
    event_3 = 11250
    event_4 = 8159
    total = event_1 + event_2 +event_3 + event_4
    
    lower_bounds = [0.0, event_1/total, (event_1 +event_2)/total, (event_1+event_2+event_3)/total]
    upper_bounds = [event_1/total, (event_1 +event_2)/total, (event_1+event_2+event_3)/total, 1.0]
    random_number = np.random.uniform(0,1)
    for i in range(4):
        if random_number >= lower_bounds[i] and random_number < upper_bounds[i]:
            guess = i
            break
    return guess

correct = 0
incorrect = 0
for i in range(599999):
    guess_1 = guess_on_distribution()
    guess_2 = guess_on_distribution()
    if guess_1 == guess_2:
        correct+=1
    else:
        incorrect+=1
        
print(correct/(correct+incorrect))