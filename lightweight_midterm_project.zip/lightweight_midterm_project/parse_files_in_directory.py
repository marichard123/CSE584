# -*- coding: utf-8 -*-
"""
Created on Tue Oct  1 00:51:52 2024

@author: rsm5599
"""
import numpy as np
import os

directory_name = 'uncurtailed_folder'
uncurtailed_filenames = os.listdir(directory_name)
for filename in uncurtailed_filenames:
    output_name =filename[0:-4] + '_curtailed.txt'
    
    with open(directory_name +'\\' +filename, "r",encoding='utf-8') as file:
        text_string = file.read().replace('\n', ' ') #read in text file, replacing new lines with spaces
    text_string = text_string.replace('  ', ' ') #replace double spaces with single spaces
    text_string = text_string.replace('?', '.') #replace all sentence ending punctuation with periods for easy splitting
    text_string = text_string.replace('!', '.')
    sentence_list = text_string.split('. ') #separate into sentences
    
    output_array = np.array(['This is the first sentence'])
    for i in sentence_list:
        #impose length range (at least 6, no more than 50), cut the sentence in half, and add it to the output array
        number_words = i.count(' ')
        if number_words >= 6 and number_words <=50:
            space_indices = [ii for ii, char in enumerate(i) if char == ' ']
            if len(space_indices) > 8:
                space_indices = space_indices[0:8]
            cutoff_index = space_indices[int(len(space_indices)/2    )      ]
            curtailed_string = i[0:cutoff_index]
            output_array = np.vstack((output_array,curtailed_string))
    
    print(len(output_array))
    np.savetxt(output_name, output_array, delimiter = '\n', fmt="%s")